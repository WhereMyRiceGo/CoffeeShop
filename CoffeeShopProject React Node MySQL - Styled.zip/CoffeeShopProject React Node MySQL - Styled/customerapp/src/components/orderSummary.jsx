import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import '../index.css';

class OrderSummary extends Component {
    state = {
        orderList: this.props.orderList,
        orderTotal: 0,
        id: this.props.orderId,
        orderProcessing: this.props.orderProcessing,
        orderStatus: "",
        disabled: false,
        className: ""
    }

    componentDidMount() {
        this.state.orderList.forEach(element => {
            this.state.orderTotal = this.state.orderTotal + Number(element.drinkPrice);
        });
        this.setState({ orderTotal: this.state.orderTotal, id: this.props.orderId });

        setInterval(() => {
            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orderId: this.state.id })
            };
            fetch('http://localhost:8000/getOrderStatus', requestOptions)
                .then(response => response.json())
                .then(data => {
                    var status = data;
                    if (status === 0) {
                        this.setState({ orderStatus: "Processing", className: "text-primary" });
                    } else if (status === 1) {
                        this.setState({ orderStatus: "Completed", className: "text-success", disabled: true });
                    } else {
                        this.setState({ orderStatus: "Cancelled", className: "text-danger" });
                    }
                })
        }, 2000);
    }


    render() {
        return (
            <div className="">
                <div className="">
                    <h5 className="mt-5">Order Submitted</h5>
                    <h5>Thank You For Your Order!</h5>
                </div>
                <div className="">
                    <h5 className="mt-5">Order Summary</h5>
                    <div className="container">
                        <div className="row 
                         mb-1 border-bottom">
                            <div className="col-sm ml-5 pl-5 text-left">
                                {this.state.orderList.map(item => <p key={item.drinkName} className="m-0">{item.drinkName}</p>)}
                            </div>
                            <div className="col-sm mr-5 pr-5 text-right">
                                {this.state.orderList.map(item => <p key={item.drinkPrice} className="m-0">${Number(item.drinkPrice).toFixed(2)}</p>)}
                            </div>
                        </div>
                        <div className="row justify-content-center mb-3">
                            <div className="col-sm ml-5 pl-5 text-left">
                                <h5>Total:</h5>
                            </div>
                            <div className="col-sm mr-5 pr-5 text-right">
                                <h5>${Number(this.state.orderTotal).toFixed(2)}</h5>
                            </div>
                        </div>

                    </div>
                    <br />

                </div>
                <div className="">
                    <h5>Order #{this.state.id}</h5>
                    {this.state.orderProcessing && <h5>Order Status: <span className={this.state.className}>{this.state.orderStatus}</span></h5>}
                </div>
                <div className="ml-5 mr-5">
                    {this.state.orderProcessing && <button className="btn btn-primary btn-lg btn-block mb-5" onClick={this.cancelOrder} disabled={this.state.disabled}>Cancel Order</button>}
                </div>
            </div>
        );
    }
    getStyle = () => {
        return "{color: green;}";
    }

    cancelOrder = () => {
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId: this.state.id })
        };
        fetch('http://localhost:8000/cancelOrder', requestOptions)
            .then(response => console.log(response))
            .then(this.setState({ disabled: true }))
    }
}

export default OrderSummary;