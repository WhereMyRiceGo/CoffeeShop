import React, { Children, Component } from 'react';
import MenuItem from './menuItem'
import OrderSummary from './orderSummary'
import 'bootstrap/dist/css/bootstrap.css';

class Menu extends Component {
    state = {
        menuList: [],
        orderList: [],
        lockBtns: true,
        showList: true,
        orderProcessing: false,
        orderId: 0
    }

    // submit order
    submitOrder = () => {
        if (window.confirm('Press OK to confirm order')) {
            // SUBMIT ORDER
            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orderList: this.state.orderList })
            };
            fetch('http://localhost:8000/submitOrder', requestOptions)
                .then(response => response.json())
                .then(data => {
                    this.setState(() => { return { orderId: data } });
                    this.state.orderId = data;
                    this.setState({ lockBtns: true, showList: false, orderProcessing: true });
                })
        } else {
            return;
        }
    }

    resetOrder = () => {
        if (window.confirm('Press OK to RESET order')) {
            const menuList = this.state.menuList.map(item => {
                item.count = 0;
                return item;
            });
            this.setState({ menuList })
            this.setState({ orderList: [], orderTotal: 0, lockBtns: true });
        } else {
            console.log("CANCELLED");
            return;
        }
    }

    handleIncrement = menuItem => {
        this.state.orderList.push(menuItem);
        const menuList = [...this.state.menuList];
        const index = menuList.findIndex(item => item.drinkName === menuItem.drinkName);
        menuList[index] = { ...menuItem };
        ++menuList[index].count;
        this.setState({ menuList, lockBtns: false });
    };


    handleDecrement = menuItem => {
        const orderList = [...this.state.orderList];
        let index = orderList.findIndex(item => item.drinkName === menuItem.drinkName);
        if (index > -1) {
            orderList.splice(index, 1);
        }
        this.setState({
            orderList: orderList
        });
        const menuList = [...this.state.menuList];
        index = menuList.findIndex(item => item.drinkName === menuItem.drinkName);
        if (menuList[index].count == 0) {
            return;
        } else {
            menuList[index] = { ...menuItem };
            --menuList[index].count;
            this.setState({ menuList });
        }
    };


    componentDidMount() {
        fetch('http://localhost:8000/getMenu')
            .then(response => response.json())
            .then(data => {
                let tempArray = []
                data.forEach(element => {
                    tempArray.push({ drinkName: element.drinkName, drinkPrice: Number(element.drinkPrice).toFixed(2), count: 0 });
                });
                this.setState(() => {
                    // Important: read `state` instead of `this.state` when updating.
                    return { menuList: tempArray }
                });
            })
    }

    render() {
        return (
            <div className=" ">
                <div className=" ">
                    <div>
                        {!this.state.showList && <OrderSummary orderList={this.state.orderList} orderId={this.state.orderId} orderProcessing={this.state.orderProcessing} />}
                        {this.state.showList && <h3 className="text-center pt-2">Menu</h3>}
                        {this.state.showList && this.state.menuList.map(item => <MenuItem key={item.drinkName} onIncrement={this.handleIncrement} onDecrement={this.handleDecrement} drinkName={item.drinkName} drinkPrice={item.drinkPrice} count={item.count} />)}
                    </div>
                    <div className="ml-5 mr-5">
                        <button className="btn btn-outline-primary btn-lg btn-block" id="submitBtn" onClick={this.submitOrder} disabled={this.state.lockBtns}>Submit Order</button><br />
                        <button className="btn btn-outline-primary btn-lg btn-block" id="resetBtn" onClick={this.resetOrder} disabled={this.state.lockBtns}>Reset Order</button>
                    </div>
                </div>
            </div>
        );
    }
}

export default Menu;