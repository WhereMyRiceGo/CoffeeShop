import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';


class MenuItem extends Component {
    state = {
        drinkName: this.props.drinkName,
        drinkPrice: this.props.drinkPrice,
    }
    render() {

        return (

            <div className="container  d-inline  ">
                <div className="row justify-content-sm-center ml-5 mr-5">
                    <div className="col-sm ">
                        <span className="align-left">{this.props.drinkName}</span>
                    </div>
                    <div className="col-sm ">
                        <span className="text-center align-middle ">${this.props.drinkPrice}</span>
                    </div>
                    <div className="col-md ">
                        <button onClick={() => this.props.onDecrement(this.props)} className="btn btn-primary btn-sm ">-</button>
                        <span className="pl-1 pr-1 pb-1 border border-primary ">{this.getCount()}</span>
                        <button onClick={() => this.props.onIncrement(this.props)} className="btn btn-primary btn-sm ">+</button>
                    </div>
                </div>
            </div>



        );
    }


    getCount() {
        return this.state.count === 0 ? '0' : this.props.count;
    }




}



export default MenuItem;