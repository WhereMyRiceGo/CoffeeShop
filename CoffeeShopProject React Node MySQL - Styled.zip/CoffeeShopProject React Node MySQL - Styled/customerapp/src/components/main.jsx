import React, { Component } from 'react';
import Menu from './menu'
import 'bootstrap/dist/css/bootstrap.css';

class Main extends Component {
    state = {}
    render() {
        return (
            <div className="" style={{ width: 400 }} >
                <div >
                    <h1 className="">Customer View</h1>
                </div>
                <Menu />
            </div>
        );
    }
}

export default Main;