// <!-- Calvin Chung - 11054307 - CAC392 - CMPT 353 PROJECT - 11/30/2020 -->
'use strict';

const express = require('express');
const app = express();
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
const mysql = require('mysql');
const cors = require('cors');
app.use(cors());


const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'coffeeshop',
});

const PORT = 8000;
const HOST = 'localhost';

/** CONNECT TO SQL DATABASE **/
db.connect(function (err) {
    if (err) console.log(err);
    console.log("Connected!");
});

/* Creates tables if they dont exist yet (i.e. first time running the program) */
setupTables();


/** GET METHODS **/

/** Fetch the menu */
app.get('/getMenu', (req, res) => {
    var sql = `SELECT * FROM menu;`;
    db.query(sql, function (err, result) {
        if (err) throw err;
        res.send(result);
    });
});



/* This method fetches the orders that are incomplete for the employee  */
app.get('/showIncompleteOrders', (req, res) => {
    var sql = "SELECT * FROM orderlist WHERE orderstatus = '0' ORDER BY orderdate ASC;";
    db.query(sql, function (err, result) {
        if (err) throw err;
        res.send(result);
    });
});


app.post('/addToMenu', (req, res) => {
    var drinkName = req.body.drinkName;
    var drinkPrice = req.body.drinkPrice;
    var sql = `REPLACE INTO menu (drinkName, drinkPrice) VALUES ("${drinkName}", "${drinkPrice}")`;
    sendQuery(sql);
    sql = `ALTER TABLE orderlist ADD COLUMN ${drinkName} smallint NOT NULL DEFAULT(0);`;
    sendQuery(sql);
    res.send("Ok");
});

app.post('/removeFromMenu', (req, res) => {
    var drinkName = req.body.drinkName;
    var sql = `DELETE FROM menu WHERE drinkName="${drinkName}";`;
    sendQuery(sql);
    sql = `ALTER TABLE orderlist DROP COLUMN ${drinkName}`;
    sendQuery(sql);
    res.send("Ok");
});

/* This POST method submits a record into the orderlist table and fetches the id of that order */
app.post('/submitOrder', (req, res) => {
    var orderArray = [];
    var order = req.body.orderList;

    // put each JSON object into an array
    order.forEach(item => {
        orderArray.push(item);
    });
    // Get the number of occurances of each drink
    var occurrences = {};
    for (var i = 0, j = orderArray.length; i < j; i++) {
        occurrences[orderArray[i].drinkName] = (occurrences[orderArray[i].drinkName] || 0) + 1;
        console.log(orderArray[i].drinkName + occurrences[orderArray[i].drinkName]);
    }
    var size = Object.keys(occurrences).length;
    // Building sql string to insert qty of each drink in the order
    var item = "";
    var count = "";
    for (var i = 0; i < size; i++) {
        item += Object.keys(occurrences)[i] + ",";
        count += Object.values(occurrences)[i] + ",";
    }
    // remove the "," from end of string
    item = item.slice(0, -1);
    count = count.slice(0, -1);

    var sql = `INSERT INTO orderlist (${item}) VALUES (${count});`;
    sendQuery(sql);

    // Fetching Order ID for Customer
    sql = "SELECT id FROM orderlist ORDER BY orderdate DESC LIMIT 0,1;";
    db.query(sql, function (err, result) {
        if (err) throw err;
        var data = JSON.stringify(result[0].id)
        res.send(data);
    });
});

/* This POST method will update the value of orderstatus when it is completed by an employee */
app.post('/completeOrder', (req, res) => {
    var id = req.body.id;
    var sql = `UPDATE orderlist SET orderstatus = '1' WHERE id = ${id}`;
    sendQuery(sql);
    res.send("Order updated and status fetched");
});

/* This POST method will update the value of orderstatus when it is cancelled by a customer */
app.post('/cancelOrder', (req, res) => {
    var orderId = req.body.orderId;
    var sql = `UPDATE orderlist SET orderstatus = '2' WHERE id = ${orderId}`;
    sendQuery(sql);
    res.send("Order updated and status fetched");
});


/* This POST method will fetch the orderstatus of a submitted order */
app.post('/getOrderStatus', (req, res) => {
    var orderId = req.body.orderId;
    var sql = `SELECT orderstatus FROM orderlist WHERE id=${orderId};`;
    db.query(sql, function (err, result) {
        if (err) throw err;
        var data = JSON.stringify(result[0].orderstatus);
        res.send(data);
    });
});

/* Function that sends query to the database */
function sendQuery(sql) {
    db.query(sql, function (err, result) {
        if (err) throw err;
    });
}

function setupTables() {
    var sql = `CREATE TABLE IF NOT EXISTS menu (id smallint NOT NULL AUTO_INCREMENT, drinkName varchar(255) NOT NULL, drinkPrice FLOAT NOT NULL, PRIMARY KEY (id), UNIQUE (drinkName));`;
    sendQuery(sql);
    sql = `CREATE TABLE IF NOT EXISTS orderlist (id smallint NOT NULL AUTO_INCREMENT, orderdate DATETIME NOT NULL DEFAULT (CURRENT_TIMESTAMP), orderstatus smallint NOT NULL DEFAULT(0), PRIMARY KEY (id));`;
    sendQuery(sql);
}

app.listen(PORT, HOST);
console.log(`Server is running on http://${HOST}:${PORT}`);
