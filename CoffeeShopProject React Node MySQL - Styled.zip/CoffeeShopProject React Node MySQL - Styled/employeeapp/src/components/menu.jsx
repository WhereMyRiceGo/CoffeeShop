
import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';

class Menu extends React.Component {
    state = {
        menuItems: []
    };

    componentDidMount = () => {
        fetch('http://localhost:8000/getMenu')
            .then(response => response.json())
            .then(data => {
                data.forEach(element => {
                    this.state.menuItems.push(element);
                });
                this.setState({ menuItems: this.state.menuItems });
            })
    }

    render() {
        return (
            <div className="">
                <h3>Menu</h3>
                <div id="menu">
                    <div className="container">
                        <div className="row justify-content-center">
                            <div className="col-sm ml-5 pl-5">
                                {this.state.menuItems.map(item => <p key={item.drinkName} className="m-0">{item.drinkName}</p>)}
                            </div>
                            <div className="col-sm mr-5 pr-5">
                                {this.state.menuItems.map(item => <p key={item.drinkPrice} className="m-0">${Number(item.drinkPrice).toFixed(2)}</p>)}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Menu;