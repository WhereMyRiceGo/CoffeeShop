
import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';

class MenuTools extends React.Component {
    state = {
        disabled: false
    }

    componentWillUnmount = () => {
        clearTimeout(this.timer);
    }

    componentDidMount() {
        setInterval(() => {
            fetch('http://localhost:8000/showIncompleteOrders')
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        this.setState({ disabled: true });
                    } else {
                        this.setState({ disabled: false });
                    }
                })
        }, 2000);
    }


    render() {
        return (
            <div className="">
                <h3>Menu Tools</h3>
                <div className="mb-4">
                    <div className="input-group input-group-sm ">
                        <div className="input-group-prepend">
                            <span className="input-group-text" id="inputGroup-sizing-sm">Name</span>
                        </div>
                        <input id="drinkName" disabled={this.state.disabled} type="text" className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" />
                        <div className="input-group input-group-sm ">
                            <div className="input-group-prepend">
                                <span className="input-group-text" id="inputGroup-sizing-sm">Price</span>
                            </div>
                            <input id="drinkPrice" disabled={this.state.disabled} value={this.state.value} onChange={this.onChange} type="text" className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" />
                        </div>
                        <button className="btn btn-outline-primary btn-sm btn-block" onClick={this.addItem} disabled={this.state.disabled}>Add Item to Menu</button>
                    </div>

                </div>
                <div className="mb-5">
                    <div className="input-group input-group-sm ">
                        <div className="input-group-prepend">
                            <span className="input-group-text" id="inputGroup-sizing-sm">Name</span>
                        </div>
                        <input id="itemToDelete" disabled={this.state.disabled} type="text" className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" />
                        <button className="btn btn-outline-primary btn-sm btn-block" onClick={this.removeItem} disabled={this.state.disabled}>Remove Item from Menu</button>
                    </div>
                </div>
            </div >
        );
    }

    onChange = (e) => {
        const re = /^[1-9][\.\d]*(,\d+)?$/;
        if (e.target.value === '' || re.test(e.target.value)) {
            this.setState({ value: e.target.value })
        }
    }

    addItem = () => {
        let drinkName = document.getElementById("drinkName").value;
        let drinkPrice = document.getElementById("drinkPrice").value;

        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ drinkName: drinkName, drinkPrice: drinkPrice })
        };
        fetch('http://localhost:8000/addtoMenu', requestOptions)
            .then(this.update())
    }

    removeItem = () => {
        let itemToDelete = document.getElementById("itemToDelete").value;
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ drinkName: itemToDelete })
        };
        fetch('http://localhost:8000/removeFromMenu', requestOptions)
            .then(this.update())
    }



    update = () => {
        location.reload();
    }
}

export default MenuTools;