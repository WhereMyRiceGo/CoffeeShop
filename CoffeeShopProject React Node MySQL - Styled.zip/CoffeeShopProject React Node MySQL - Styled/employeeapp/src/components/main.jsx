import React, { Component } from 'react';
import MenuTools from './menuTools';
import OpenOrders from './openOrders'
import Menu from './menu';
import 'bootstrap/dist/css/bootstrap.css';

class Main extends React.Component {


    render() {
        return (
            <div className="" style={{ width: 500 }} >
                <h1 className="">Employee View</h1>
                <br />
                <Menu />
                <br />
                <div className="row w-100" >
                    <div className="col" >
                        <MenuTools />
                    </div>
                    <div className="col ">
                        <OpenOrders />
                    </div>
                </div>
            </div>
        );


    }
}

export default Main;