import React, { Component } from 'react';
import Items from './items';
import 'bootstrap/dist/css/bootstrap.css';

class Order extends React.Component {
    state = {
        id: this.props.id,
        orderDate: this.props.orderdate,
        orderStatus: this.props.orderstatus,
        items: this.props.items,
        newItems: [],
        lockBtn: false,
        refresh: false,
        className: "text-primary"
    }

    componentWillUnmount = () => {
        clearTimeout(this.timer);
    }

    componentDidMount = () => {
        Object.entries(this.state.items).forEach(([key, value]) => {

            this.state.newItems.push({ name: key, qty: value });
        });
        this.setState(() => { return { newItems: this.state.newItems } });
        const timer = setTimeout(() => { this.setState({ refresh: true }); }, 5000);

    }

    render() {
        return (
            <div>
                <h5 className="mb-0">Order #{this.state.id}</h5>
                Order Date: {this.state.orderDate}<br />
                Status: <span className={this.state.className}>{this.getOrderStatus()}</span><br />
                <Items newItems={this.state.newItems} />
                <button className="btn btn-outline-success" onClick={this.setComplete} disabled={this.state.lockBtn}>Complete</button>
                <br />
                <br />
            </div>
        );
    }

    setComplete = () => {
        this.setState({ lockBtn: true, orderStatus: 1 });
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: this.state.id })
        };
        fetch('http://localhost:8000/completeOrder', requestOptions)
            .then(response => console.log(response))
            .then(this.setState(() => { return { className: "text-success" } }))
    }

    getOrderStatus = () => {
        if (this.state.orderStatus === 0) {
            return "Processing";
        } else if (this.state.orderStatus === 1) {
            return "Complete";
        } else {
            return "Cancelled";
        }
    }

}

export default Order;