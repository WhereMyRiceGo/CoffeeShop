import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';

class Items extends React.Component {
    state = {
        list: this.props.newItems,
        refresh: false
    }

    UNSAFE_componentWillReceiveProps(nextProps) {
        this.setState({ list: nextProps.newItems });
        var filtered = this.state.list.filter(item => item.qty !== 0);
        this.setState(() => {
            return { list: filtered, refresh: true };
        });
    }

    render() {
        return (
            <div>
                {this.state.list.map(item => <p key={item.name} className="m-0">{item.qty} x {item.name}</p>)}
            </div>
        );
    }
}

export default Items;