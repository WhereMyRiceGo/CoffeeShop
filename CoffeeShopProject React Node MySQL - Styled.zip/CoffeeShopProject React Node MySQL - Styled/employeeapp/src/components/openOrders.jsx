import React, { Component } from 'react';
import Order from './order';
import 'bootstrap/dist/css/bootstrap.css';


class OpenOrders extends React.Component {
    state = {
        openOrders: [],
        reload: false
    }

    componentDidMount = () => {
        //Setup continuous listener for updates on orders incoming
        setInterval(() => {
            fetch('http://localhost:8000/showIncompleteOrders')
                .then(response => response.json())
                .then(data => {
                    let tempArray = [];
                    data.forEach(element => {
                        tempArray.push(element);
                    });
                    // Remove the 0 qty items
                    let newArray = [];
                    tempArray.forEach(element => {
                        var id = element.id;
                        var orderdate = element.orderdate;
                        var orderstatus = element.orderstatus;
                        delete element.id;
                        delete element.orderdate;
                        delete element.orderstatus;
                        newArray.push({ id: id, orderdate: orderdate, orderstatus: orderstatus, items: element });
                    });
                    this.setState(() => { return { openOrders: newArray } });
                })
        }, 3000);

    }

    render() {
        return (
            <div className="">
                <h3>Open Orders <span className="badge badge-pill badge-primary">{this.getNumOrders()}</span></h3>
                {this.state.openOrders.map(order => <Order key={order.orderdate} id={order.id} orderdate={order.orderdate} orderstatus={order.orderstatus} items={order.items} />)}
            </div>
        );
    }

    getNumOrders = () => {
        let count = this.state.openOrders.length;
        if (count === 0) {
            return "";
        } else {
            return count;
        }
    }


}

export default OpenOrders;